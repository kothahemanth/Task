sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("com.hemanth.satinfotech.branch.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);